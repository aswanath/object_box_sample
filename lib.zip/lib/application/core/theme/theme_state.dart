part of 'theme_bloc.dart';

class ThemeState {
  final ThemeData themeData;
  final IconData iconData;

  ThemeState({
    required this.themeData,
    required this.iconData,
  });
}
